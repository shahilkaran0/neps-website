NEPS WEBSITE PACKAGE

1. Extract this ZIP in the Files app or on a computer.
2. Open index.html in Safari, Chrome, or another browser to preview.
3. The website includes the NEPS logo and current contact details.

Contact details included:
Phone: 9039344
Email: nepsfiji@gmail.com
Location: Navua, Fiji; servicing Fiji-wide.

The enquiry form is configured to prepare an email to the company address. Before publishing, test the form and confirm the phone and email details.

FREE PUBLISHING WITH GITHUB PAGES:
1. Create/sign in to GitHub.
2. Create a public repository named neps-website.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. GitHub will provide your public website address after deployment.
